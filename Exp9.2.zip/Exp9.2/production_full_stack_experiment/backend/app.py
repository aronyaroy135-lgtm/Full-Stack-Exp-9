import os
import sqlite3
from pathlib import Path

from flask import Flask, current_app, g, jsonify, request, send_from_directory


PROJECT_ROOT = Path(__file__).resolve().parent.parent
FRONTEND_DIR = PROJECT_ROOT / "frontend"


def get_db():
    if "db" not in g:
        db_path = current_app.config["DATABASE"]
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        g.db = sqlite3.connect(db_path, timeout=10)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL CHECK(length(title) BETWEEN 1 AND 200),
            completed INTEGER NOT NULL DEFAULT 0 CHECK(completed IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    db.commit()


def create_app(test_config=None):
    app = Flask(__name__, static_folder=None)
    default_db = os.environ.get("TASKS_DATABASE", str(PROJECT_ROOT / "instance" / "tasks.sqlite3"))
    app.config.from_mapping(
        DATABASE=default_db,
        MAX_CONTENT_LENGTH=16 * 1024,
        JSON_SORT_KEYS=False,
    )
    if test_config:
        app.config.update(test_config)

    app.teardown_appcontext(close_db)

    with app.app_context():
        init_db()

    @app.after_request
    def add_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Cache-Control", "no-store")
        return response

    @app.errorhandler(413)
    def request_too_large(_error):
        return jsonify(error="Request body is too large"), 413

    @app.get("/")
    def index():
        return send_from_directory(FRONTEND_DIR, "index.html")

    @app.get("/<path:filename>")
    def frontend_assets(filename):
        if filename in {"style.css", "app.js"}:
            return send_from_directory(FRONTEND_DIR, filename)
        return jsonify(error="Not found"), 404

    @app.get("/api/health")
    def health():
        try:
            get_db().execute("SELECT 1").fetchone()
            return jsonify(status="ok", database="ok")
        except sqlite3.Error:
            current_app.logger.exception("Database health check failed")
            return jsonify(status="error", database="unavailable"), 503

    @app.get("/api/tasks")
    def list_tasks():
        rows = get_db().execute(
            "SELECT id, title, completed, created_at FROM tasks ORDER BY id DESC"
        ).fetchall()
        return jsonify([serialize_task(row) for row in rows])

    @app.post("/api/tasks")
    def create_task():
        if not request.is_json:
            return jsonify(error="Content-Type must be application/json"), 415
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(error="A JSON object is required"), 400
        title = data.get("title")
        if not isinstance(title, str) or not title.strip():
            return jsonify(error="Task title is required"), 400
        title = title.strip()
        if len(title) > 200:
            return jsonify(error="Task title must be 200 characters or fewer"), 400

        db = get_db()
        cursor = db.execute("INSERT INTO tasks (title) VALUES (?)", (title,))
        db.commit()
        row = db.execute(
            "SELECT id, title, completed, created_at FROM tasks WHERE id = ?",
            (cursor.lastrowid,),
        ).fetchone()
        return jsonify(serialize_task(row)), 201

    @app.patch("/api/tasks/<int:task_id>")
    def toggle_task(task_id):
        db = get_db()
        row = db.execute("SELECT completed FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if row is None:
            return jsonify(error="Task not found"), 404
        updated = 0 if row["completed"] else 1
        db.execute("UPDATE tasks SET completed = ? WHERE id = ?", (updated, task_id))
        db.commit()
        row = db.execute(
            "SELECT id, title, completed, created_at FROM tasks WHERE id = ?",
            (task_id,),
        ).fetchone()
        return jsonify(serialize_task(row))

    @app.delete("/api/tasks/<int:task_id>")
    def delete_task(task_id):
        db = get_db()
        cursor = db.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        db.commit()
        if cursor.rowcount == 0:
            return jsonify(error="Task not found"), 404
        return "", 204

    return app


def serialize_task(row):
    return {
        "id": row["id"],
        "title": row["title"],
        "completed": bool(row["completed"]),
        "created_at": row["created_at"],
    }


app = create_app()

if __name__ == "__main__":
    # Development convenience only. Use Gunicorn in production/container deployments.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
