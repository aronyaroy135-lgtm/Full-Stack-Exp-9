# Experiment: Production-Oriented Full-Stack Application

## Aim
To design and develop a production-ready full-stack application integrating all system components.

## Objectives
1. Integrate a responsive frontend with a backend REST API.
2. Persist application data in an SQLite database.
3. Implement validated CRUD operations, error handling, and health checks.
4. Apply production-oriented practices such as environment-based configuration, security headers, non-root container execution, and automated tests.
5. Package the application for reproducible local and container deployment.

## Software Requirements
- Python 3.11 or later
- Git (optional, for version control)
- Docker (optional, for containerized execution)
- A modern web browser

## Theory
A full-stack application includes the presentation layer, application/API layer, and data layer. The browser-based frontend communicates with backend endpoints over HTTP using JSON. The backend validates input, applies application rules, and stores records in a database.

This project is a Task Manager built with HTML, CSS, and JavaScript, a Flask REST API, and SQLite persistence. It uses an application factory, environment-based configuration, parameterized SQL queries, input validation, consistent JSON errors, health checks, security response headers, automated tests, and a non-root Docker image. Gunicorn is used as the production WSGI server in the container.

**Production note:** This is a production-oriented educational starter, not a claim of complete enterprise readiness. Before exposing it to the public internet, add authentication/authorization, HTTPS and reverse-proxy configuration, backups, monitoring, database migration strategy, and operational security review. SQLite is suitable for a small demo; use a managed database for many concurrent users or multi-instance deployments.

## System Architecture
```text
Browser (HTML / CSS / JavaScript)
             |
       HTTP + JSON
             |
       Flask REST API
   validation / error handling
             |
        SQLite database
```

## Project Structure
```text
production_full_stack_experiment/
├── backend/
│   ├── __init__.py
│   └── app.py
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── tests/
│   └── test_app.py
├── .github/workflows/ci.yml
├── Dockerfile
├── compose.yaml
├── requirements.txt
├── .dockerignore
├── .gitignore
└── README.md
```

## Procedure
1. Extract the ZIP archive.
2. Install Python 3.11+.
3. From the project directory, install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
4. Run the automated tests:
   ```bash
   python -m pytest -v
   ```
5. Start the application locally:
   ```bash
   python -m backend.app
   ```
6. Open `http://127.0.0.1:5000` in the browser.
7. Add tasks, mark tasks complete/incomplete, and delete tasks. Refresh the page and confirm that data persists in the SQLite database.
8. Check the API health endpoint at `http://127.0.0.1:5000/api/health`.
9. Optional Docker run:
   ```bash
   docker compose up --build
   ```
   Open `http://127.0.0.1:8000`. Stop with `docker compose down`. The named volume retains database data.
10. Inspect `.github/workflows/ci.yml` to see automated syntax checks and tests on pushes and pull requests.

## API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Health status |
| GET | `/api/tasks` | List tasks |
| POST | `/api/tasks` | Create a task |
| PATCH | `/api/tasks/<id>` | Toggle task completion |
| DELETE | `/api/tasks/<id>` | Delete a task |

## Expected Output
- A responsive Task Manager interface is displayed.
- New tasks are created through the backend and stored in SQLite.
- Complete and delete operations update the database.
- Invalid task titles receive a clear HTTP 400 JSON response.
- The health endpoint returns `{"status":"ok"}`.
- Automated tests pass.

## Result
A production-oriented full-stack Task Manager was developed by integrating a responsive browser frontend, Flask REST API, and SQLite database. The project includes validation, structured error handling, security headers, automated tests, container support, and CI configuration.

## Viva-Voce Questions
1. What are the frontend, backend, and data layers?
2. What is a REST API?
3. Why is JSON used for communication?
4. What is CRUD?
5. Why should SQL queries be parameterized?
6. What is an application factory?
7. What is the purpose of a health endpoint?
8. Why should a production server use Gunicorn instead of Flask's development server?
9. What are environment variables used for?
10. Why are backups, authentication, HTTPS, and monitoring important in production?

## Conclusion
The experiment integrates all major components of a full-stack system and demonstrates practical engineering measures for validation, persistence, deployment, testing, and maintainability.
