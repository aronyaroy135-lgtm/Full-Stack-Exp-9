import pytest

from backend.app import create_app


@pytest.fixture()
def client(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.sqlite3")})
    with app.test_client() as client:
        yield client


def test_home_page_and_assets(client):
    assert client.get("/").status_code == 200
    assert b"Task Manager" in client.get("/").data
    assert client.get("/app.js").status_code == 200
    assert client.get("/style.css").status_code == 200


def test_health_endpoint(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.get_json() == {"status": "ok", "database": "ok"}


def test_create_and_list_task(client):
    response = client.post("/api/tasks", json={"title": "Prepare lab report"})
    assert response.status_code == 201
    assert response.get_json()["title"] == "Prepare lab report"
    assert response.get_json()["completed"] is False
    assert len(client.get("/api/tasks").get_json()) == 1


def test_reject_invalid_task_titles(client):
    assert client.post("/api/tasks", json={"title": "  "}).status_code == 400
    assert client.post("/api/tasks", json={"title": "x" * 201}).status_code == 400
    assert client.post("/api/tasks", data="not-json", content_type="text/plain").status_code == 415


def test_toggle_delete_and_missing_task(client):
    created = client.post("/api/tasks", json={"title": "Review code"}).get_json()
    task_id = created["id"]
    toggled = client.patch(f"/api/tasks/{task_id}")
    assert toggled.status_code == 200
    assert toggled.get_json()["completed"] is True
    assert client.delete(f"/api/tasks/{task_id}").status_code == 204
    assert client.delete(f"/api/tasks/{task_id}").status_code == 404
    assert client.patch("/api/tasks/9999").status_code == 404


def test_data_persists_after_request(client):
    client.post("/api/tasks", json={"title": "Persistent task"})
    assert client.get("/api/tasks").get_json()[0]["title"] == "Persistent task"


def test_security_headers(client):
    response = client.get("/api/health")
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
