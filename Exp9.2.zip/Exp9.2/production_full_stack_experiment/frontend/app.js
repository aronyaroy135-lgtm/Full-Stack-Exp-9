const form = document.querySelector("#task-form");
const titleInput = document.querySelector("#task-title");
const taskList = document.querySelector("#task-list");
const emptyState = document.querySelector("#empty-state");
const taskCount = document.querySelector("#task-count");
const statusMessage = document.querySelector("#status");
const apiStatus = document.querySelector("#api-status");

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) },
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${response.status})`);
  }
  return response.status === 204 ? null : response.json();
}

function renderTasks(tasks) {
  taskList.replaceChildren();
  emptyState.hidden = tasks.length !== 0;
  taskCount.textContent = `${tasks.length} task${tasks.length === 1 ? "" : "s"}`;

  for (const task of tasks) {
    const item = document.createElement("li");
    item.className = `task${task.completed ? " completed" : ""}`;

    const title = document.createElement("span");
    title.className = "task-title";
    // Use textContent, not innerHTML, so task titles are never interpreted as markup.
    title.textContent = task.title;

    const actions = document.createElement("div");
    actions.className = "task-actions";

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.textContent = task.completed ? "Reopen" : "Complete";
    toggle.setAttribute("aria-label", `${task.completed ? "Reopen" : "Complete"} ${task.title}`);
    toggle.addEventListener("click", () => perform(async () => {
      await api(`/api/tasks/${task.id}`, { method: "PATCH" });
      await loadTasks();
    }));

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "delete";
    remove.textContent = "Delete";
    remove.setAttribute("aria-label", `Delete ${task.title}`);
    remove.addEventListener("click", () => perform(async () => {
      await api(`/api/tasks/${task.id}`, { method: "DELETE" });
      await loadTasks();
    }));

    actions.append(toggle, remove);
    item.append(title, actions);
    taskList.append(item);
  }
}

async function loadTasks() {
  renderTasks(await api("/api/tasks"));
}

async function perform(operation) {
  statusMessage.textContent = "";
  try {
    await operation();
  } catch (error) {
    statusMessage.textContent = error.message || "An unexpected error occurred.";
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const title = titleInput.value.trim();
  if (!title) {
    statusMessage.textContent = "Please enter a task title.";
    return;
  }
  perform(async () => {
    await api("/api/tasks", { method: "POST", body: JSON.stringify({ title }) });
    titleInput.value = "";
    await loadTasks();
    titleInput.focus();
  });
});

(async function start() {
  try {
    await api("/api/health");
    await loadTasks();
    apiStatus.textContent = "Backend connected";
  } catch (error) {
    apiStatus.textContent = "Backend unavailable";
    apiStatus.classList.add("offline");
    statusMessage.textContent = error.message;
  }
})();
