import pytest

from backend.app import create_app


@pytest.fixture()
def client():
    app = create_app()
    app.config.update(TESTING=True)
    return app.test_client()


def test_home_page_serves_frontend(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"Task Manager" in response.data


def test_health_endpoint(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.get_json() == {"status": "ok"}


def test_create_and_list_task(client):
    created = client.post("/api/tasks", json={"title": "Write report"})
    assert created.status_code == 201
    assert created.get_json()["title"] == "Write report"
    listed = client.get("/api/tasks")
    assert len(listed.get_json()) == 1


def test_reject_blank_task(client):
    response = client.post("/api/tasks", json={"title": "   "})
    assert response.status_code == 400


def test_toggle_and_delete_task(client):
    created = client.post("/api/tasks", json={"title": "Review code"})
    task_id = created.get_json()["id"]
    toggled = client.patch(f"/api/tasks/{task_id}")
    assert toggled.status_code == 200
    assert toggled.get_json()["completed"] is True
    deleted = client.delete(f"/api/tasks/{task_id}")
    assert deleted.status_code == 204
    assert client.get("/api/tasks").get_json() == []
