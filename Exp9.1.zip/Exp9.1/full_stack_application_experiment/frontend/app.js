const form = document.querySelector("#task-form");
const titleInput = document.querySelector("#task-title");
const taskList = document.querySelector("#task-list");
const emptyState = document.querySelector("#empty-state");
const taskCount = document.querySelector("#task-count");
const statusMessage = document.querySelector("#status");
const apiStatus = document.querySelector("#api-status");

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${response.status})`);
  }
  return response.status === 204 ? null : response.json();
}

function renderTasks(tasks) {
  taskList.replaceChildren();
  emptyState.hidden = tasks.length > 0;
  taskCount.textContent = `${tasks.length} task${tasks.length === 1 ? "" : "s"}`;

  for (const task of tasks) {
    const item = document.createElement("li");
    item.className = `task${task.completed ? " completed" : ""}`;

    const title = document.createElement("span");
    title.className = "task-title";
    title.textContent = task.title;

    const actions = document.createElement("div");
    actions.className = "task-actions";

    const completeButton = document.createElement("button");
    completeButton.type = "button";
    completeButton.textContent = task.completed ? "Reopen" : "Complete";
    completeButton.addEventListener("click", async () => {
      await perform(async () => {
        await api(`/api/tasks/${task.id}`, { method: "PATCH" });
        await loadTasks();
      });
    });

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.className = "delete";
    deleteButton.textContent = "Delete";
    deleteButton.addEventListener("click", async () => {
      await perform(async () => {
        await api(`/api/tasks/${task.id}`, { method: "DELETE" });
        await loadTasks();
      });
    });

    actions.append(completeButton, deleteButton);
    item.append(title, actions);
    taskList.append(item);
  }
}

async function loadTasks() {
  const tasks = await api("/api/tasks");
  renderTasks(tasks);
}

async function perform(operation) {
  statusMessage.textContent = "";
  try {
    await operation();
  } catch (error) {
    statusMessage.textContent = error.message;
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const title = titleInput.value.trim();
  if (!title) {
    statusMessage.textContent = "Please enter a task description.";
    return;
  }
  await perform(async () => {
    await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({ title }),
    });
    titleInput.value = "";
    await loadTasks();
  });
});

(async function start() {
  try {
    await loadTasks();
    await api("/api/health");
    apiStatus.textContent = "Backend connected";
  } catch (error) {
    apiStatus.textContent = "Backend unavailable";
    apiStatus.classList.add("offline");
    statusMessage.textContent = error.message;
  }
})();
