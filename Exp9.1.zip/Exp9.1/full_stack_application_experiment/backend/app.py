from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

ROOT = Path(__file__).resolve().parent.parent
FRONTEND = ROOT / "frontend"


def create_app():
    app = Flask(__name__, static_folder=None)
    app.config["TASKS"] = []
    app.config["NEXT_ID"] = 1

    @app.get("/")
    def index():
        return send_from_directory(FRONTEND, "index.html")

    @app.get("/<path:filename>")
    def frontend_assets(filename):
        if filename in {"style.css", "app.js"}:
            return send_from_directory(FRONTEND, filename)
        return jsonify(error="Not found"), 404

    @app.get("/api/health")
    def health():
        return jsonify(status="ok")

    @app.get("/api/tasks")
    def list_tasks():
        return jsonify(app.config["TASKS"])

    @app.post("/api/tasks")
    def create_task():
        data = request.get_json(silent=True) or {}
        title = data.get("title")
        if not isinstance(title, str) or not title.strip():
            return jsonify(error="Task title is required"), 400
        title = title.strip()
        if len(title) > 200:
            return jsonify(error="Task title must be 200 characters or fewer"), 400

        task = {
            "id": app.config["NEXT_ID"],
            "title": title,
            "completed": False,
        }
        app.config["NEXT_ID"] += 1
        app.config["TASKS"].append(task)
        return jsonify(task), 201

    @app.patch("/api/tasks/<int:task_id>")
    def toggle_task(task_id):
        task = next((item for item in app.config["TASKS"] if item["id"] == task_id), None)
        if task is None:
            return jsonify(error="Task not found"), 404
        task["completed"] = not task["completed"]
        return jsonify(task)

    @app.delete("/api/tasks/<int:task_id>")
    def delete_task(task_id):
        tasks = app.config["TASKS"]
        task = next((item for item in tasks if item["id"] == task_id), None)
        if task is None:
            return jsonify(error="Task not found"), 404
        tasks.remove(task)
        return "", 204

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
