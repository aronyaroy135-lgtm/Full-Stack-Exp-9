# Experiment: Design and Integrate Frontend and Backend Components into a Full-Stack Application

## Aim
To design and integrate frontend and backend components into a complete full-stack application.

## Objectives
1. Build a user-friendly frontend using HTML, CSS, and JavaScript.
2. Implement backend REST API endpoints using Python and Flask.
3. Connect the frontend to the backend using HTTP requests and JSON.
4. Validate application behavior with automated backend tests.

## Software Requirements
- Python 3.10 or later
- A modern web browser
- Internet access for installing dependencies (first setup only)
- Optional: Visual Studio Code

## Theory
A full-stack application contains a frontend (the user interface) and a backend (application logic and API). The frontend runs in the browser and sends HTTP requests to the backend. The backend processes requests and returns responses, commonly in JSON format. In this experiment, HTML/CSS/JavaScript form the frontend and Flask provides the REST API. The frontend and backend are served by the same Flask application, avoiding cross-origin configuration for this simple demonstration.

## Project Structure
```text
full_stack_application_experiment/
├── backend/
│   ├── __init__.py
│   └── app.py
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── tests/
│   └── test_app.py
├── requirements.txt
└── README.md
```

## Procedure
1. Install Python 3.10 or later.
2. Extract the ZIP file and open a terminal in the project directory.
3. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
4. Start the backend and web server:
   ```bash
   python -m backend.app
   ```
5. Open `http://127.0.0.1:5000` in a browser.
6. Enter a task in the input field and click **Add task**. The frontend sends a POST request to `/api/tasks`.
7. Confirm the new task appears in the task list. Use the **Complete** button to update its status through the backend API, or **Delete** to remove it.
8. Run automated tests:
   ```bash
   python -m pytest -v
   ```

## API Endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/tasks` | Return all tasks as JSON |
| POST | `/api/tasks` | Create a task |
| PATCH | `/api/tasks/<id>` | Toggle task completion |
| DELETE | `/api/tasks/<id>` | Delete a task |
| GET | `/api/health` | Health check |

Note: This teaching example stores tasks in memory. Tasks reset when the server restarts; a production application should use a persistent database and authentication where appropriate.

## Expected Output
- The browser displays a task manager interface.
- Adding a task sends a request to the backend and returns the created task.
- Completing or deleting a task updates the backend data and refreshes the interface.
- Automated API tests pass.

## Result
A full-stack task manager was implemented using an HTML/CSS/JavaScript frontend and a Python Flask backend. The frontend communicates with REST API endpoints using JSON over HTTP.

## Viva-Voce Questions
1. What is a full-stack application?
2. What is the difference between frontend and backend?
3. What is a REST API?
4. What is JSON, and why is it used?
5. What is the purpose of HTTP GET, POST, PATCH, and DELETE?
6. Why is input validation important?
7. What is the role of automated tests?
8. Why should a production application use persistent storage?

## Conclusion
The experiment demonstrates the integration of frontend and backend components through REST API requests, creating a functional full-stack application.
